/**
 * Plug-in points for turning this from a scenario sandbox into a real
 * client-consultation tool.
 *
 * Nothing in this file is a real insurance rate. `PLACEHOLDER_CARRIERS`
 * exists so the UI can demonstrate "compare rates by issuing company"
 * without pretending to have real carrier data. Swap
 * `getPremiumMultiplier` for a call to an actual rating engine / carrier
 * API / underwriting spreadsheet when that data is available — the shape
 * of the interface is intentionally stable so the rest of the app doesn't
 * need to change.
 */

export type Carrier = {
  id: string;
  name: string;
  /** True until real rate data is wired in. Always show this in the UI. */
  isPlaceholder: boolean;
};

export type RateQuery = {
  hazardId: string;
  location: string;
  carrierId: string;
  /** 0-1, modeled loss severity for this scenario from the simulator */
  scenarioSeverity: number;
};

export type RateResult = {
  /** Illustrative multiplier applied to a baseline premium. NOT a real quote. */
  premiumMultiplier: number;
  isPlaceholder: boolean;
  explanation: string;
};

export const PLACEHOLDER_CARRIERS: Carrier[] = [
  { id: "baseline", name: "Baseline / regional average", isPlaceholder: true },
  { id: "carrier-a", name: "Carrier A (placeholder)", isPlaceholder: true },
  { id: "carrier-b", name: "Carrier B (placeholder)", isPlaceholder: true },
];

/**
 * TODO(plug-in point): replace this with a real rating call, e.g.
 *   const res = await fetch(`/api/carriers/${carrierId}/rate`, { ... })
 * or a lookup against an imported carrier rate table once a partner
 * insurer provides one. Until then this returns a clearly-labeled
 * illustrative multiplier so the UI has something to render.
 */
export function getPremiumMultiplier(query: RateQuery): RateResult {
  const carrier = PLACEHOLDER_CARRIERS.find((c) => c.id === query.carrierId) ?? PLACEHOLDER_CARRIERS[0];
  const carrierSpread: Record<string, number> = {
    baseline: 1.0,
    "carrier-a": 1.12,
    "carrier-b": 0.91,
  };
  const spread = carrierSpread[carrier.id] ?? 1.0;
  const multiplier = Math.round((1 + query.scenarioSeverity * 1.8) * spread * 100) / 100;

  return {
    premiumMultiplier: multiplier,
    isPlaceholder: true,
    explanation:
      "Illustrative only — no real carrier rate data is connected yet. Wire this to an actual rate table or carrier API to make this figure real.",
  };
}
