/**
 * Real historical flood-disaster frequency, sourced from NOAA/NCEI's
 * U.S. Billion-Dollar Weather and Climate Disasters database (1980-2024).
 *
 * This is the ONE hazard in the simulator currently backed by an actual
 * public dataset rather than an illustrative placeholder. It only counts
 * events that individually exceeded $1B in damages and were classified as
 * "Flooding" (river-basin or urban flooding from excessive rainfall,
 * counted separately from inland flood damage caused by tropical
 * cyclones). It is a coarse, low-resolution proxy for flood exposure —
 * not a FEMA flood-zone determination, not a NFIP claims history, and not
 * a substitute for parcel-level flood modeling.
 *
 * Source: NOAA National Centers for Environmental Information (NCEI),
 * "U.S. Billion-Dollar Weather and Climate Disasters," state summaries,
 * https://www.ncei.noaa.gov/access/billions/state-summary/{STATE}
 * (archived; NCEI ceased updating this product after the 2024 data year).
 * Retrieved and transcribed manually — figures should be re-verified
 * against the archived NCEI tables before any client-facing use.
 */

export type StateFloodRecord = {
  state: string;
  stateCode: string;
  /** Count of individual billion-dollar flood events, 1980-2024 */
  billionDollarFloodEvents: number;
  /** Total billion-dollar weather/climate events of any type, 1980-2024, for context */
  totalBillionDollarEvents: number;
  /** Annual average frequency of ANY billion-dollar disaster type (CPI-adjusted), 1980-2024 */
  annualAvgAnyDisaster: number;
};

export const NOAA_FLOOD_SOURCE = {
  name: "NOAA NCEI — U.S. Billion-Dollar Weather and Climate Disasters",
  period: "1980-2024",
  url: "https://www.ncei.noaa.gov/access/billions/",
  note: "Counts only events with $1B+ in aggregate damages; not a complete flood-event record.",
};

export const stateFloodHistory: StateFloodRecord[] = [
  { state: "Florida", stateCode: "FL", billionDollarFloodEvents: 4, totalBillionDollarEvents: 94, annualAvgAnyDisaster: 2.1 },
  { state: "California", stateCode: "CA", billionDollarFloodEvents: 6, totalBillionDollarEvents: 46, annualAvgAnyDisaster: 1.0 },
  { state: "Texas", stateCode: "TX", billionDollarFloodEvents: 9, totalBillionDollarEvents: 190, annualAvgAnyDisaster: 4.9 },
  { state: "Louisiana", stateCode: "LA", billionDollarFloodEvents: 10, totalBillionDollarEvents: 97, annualAvgAnyDisaster: 2.4 },
];

export const NATIONAL_FLOOD_SUMMARY = {
  billionDollarFloodEvents: 45,
  annualAvgEvents: 1.0,
  costPerEventUSD: 4.5e9,
  deathsPerYear: 17,
};

/** Loose lookup: matches a free-text place string (e.g. "Florida, USA") to a state record. */
export function lookupFloodHistory(place: string): StateFloodRecord | null {
  const lower = place.toLowerCase();
  return stateFloodHistory.find((rec) => lower.includes(rec.state.toLowerCase())) ?? null;
}
