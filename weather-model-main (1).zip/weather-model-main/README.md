# Weather Model

An interactive risk-consultation tool for weather professionals and
insurance-adjacent advisors. Select a hazard, place it on a map, and walk
a client through modeled impacts on people, power systems, health,
batteries, displacement, air quality, economic activity, and recovery —
then compare illustrative rate impact across issuing companies.

> **Honesty first:** this project is explicitly built as "some real walls,
> some open ones." Flood-event frequency for a handful of U.S. states is
> backed by real NOAA/NCEI historical data (cited below). Every other
> hazard's coefficients, and every rate/premium figure, is a clearly
> labeled placeholder — a stand-in for data that isn't connected yet.
> **Nothing in this tool should be used for actual underwriting,
> investment, evacuation, medical, or emergency-management decisions.**
> It's a sales/education aid with room to grow into something calibrated.

## What's real today

- **U.S. flood-event history** (Florida, California, Texas, Louisiana) —
  count of billion-dollar flood disasters, 1980-2024, from NOAA NCEI's
  U.S. Billion-Dollar Weather and Climate Disasters database
  (`app/data/noaaFloodHistory.ts`). This is a coarse floor (only counts
  $1B+ events), not a FEMA flood-zone or NFIP claims history.

## What's a placeholder, on purpose

- All non-flood hazard coefficients in `app/page.tsx` (hurricane,
  blizzard, wildfire, heat, earthquake, drought, air pollution) —
  illustrative, not calibrated to any dataset.
- The resilience-mitigation math (battery/medical/filtration relief
  factors).
- Every number in the "Rate comparison by issuing company" panel
  (`app/lib/rateTable.ts`) — three fictional placeholder carriers with a
  fake multiplier formula, deliberately structured behind a stable
  `RateQuery -> RateResult` interface so a real carrier API or rate table
  can be dropped in later without touching the UI.

## Plug-in points (the "open wallspace")

- `app/data/noaaFloodHistory.ts` — extend `stateFloodHistory` with more
  states, or replace the static array with a live NCEI/NWS API call.
- `app/lib/rateTable.ts` — replace `getPremiumMultiplier` with a real
  rating call once a carrier partner provides one.
- Location input is currently click-anywhere-on-a-flat-map; swapping in
  real geocoding would let this key off an actual address/county.

## Development

Requirements: Node.js 22.13 or newer.

```bash
npm install
npm run dev
```

Build the production bundle:

```bash
npm run build
```

## Production-data roadmap

- NOAA, NASA, Copernicus, USGS and WMO hazard data for every hazard type
  (flood is the only one started)
- EIA, ENTSO-E and regional system-operator grid data
- OpenStreetMap infrastructure
- WorldPop or equivalent population surfaces
- WHO health-response functions
- FEMA flood-zone data and peer-reviewed regional vulnerability/loss
  functions
- A real carrier rate-table or rating-API integration
- Explicit uncertainty ranges, provenance and versioned model assumptions

## Sources

- NOAA National Centers for Environmental Information (NCEI), "U.S.
  Billion-Dollar Weather and Climate Disasters," state summaries,
  https://www.ncei.noaa.gov/access/billions/ (archived; NCEI stopped
  updating this product after the 2024 data year — figures here should be
  re-verified before client-facing use).

## Map attribution

The world-map base is loaded from Wikimedia Commons and derives from a
CC0/public-domain equirectangular map. See the in-app footer for
attribution.

## License

No license has been selected yet. Add a license before accepting external
contributions or redistributing the project.
